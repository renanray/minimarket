<script>
    window.print();
</script>